import './assets/MovieInputStyles.css'
import './assets/MovieItemStyles.css'
import './assets/App.css'

import { createApp } from 'vue'
import App from './App.vue'



createApp(App).mount('#app')


