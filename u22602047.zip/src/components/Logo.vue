<script>
export default{
  name:'Logo'
}
</script>

<template>
    <div class="logo">
      VUED.
    </div>
</template>



<style >

.logo {
  display: flex;
  justify-content: center;
  align-items: center;
  color: #41b883;
  font-weight: bolder;
  font-size:125px;
}

</style>